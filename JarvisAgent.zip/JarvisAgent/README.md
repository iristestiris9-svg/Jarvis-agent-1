# Jarvis Agent (Android, free Gemini version)
1. Free key: aistudio.google.com -> Get API key -> Create API key (AIza...).
2. Android Studio -> Open this folder -> Gradle sync -> Run on phone.
3. App me key paste karo. "Enable Control" -> Accessibility me Jarvis Agent ON.
4. Bolo: "Mummy ko WhatsApp pe good morning bhejo, phir 7 baje ka alarm lagao".
Model name Planner.kt me (gemini-2.5-flash). 404 aaye to naam badlo.
