package com.jarvis.agent.tools

import android.Manifest
import android.app.SearchManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import com.jarvis.agent.agent.*
import com.jarvis.agent.service.JarvisAccessibilityService
import kotlinx.coroutines.delay
import org.json.JSONObject
import java.net.URLEncoder

private fun go(c: Context, i: Intent): ToolResult {
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return try { c.startActivity(i); ToolResult(true, "done") } catch (e: Exception) { ToolResult(false, "No app can do this: ${e.message}") }
}

private fun resolveNumber(c: Context, s: String): String? {
    if (s.any { it.isDigit() } && s.count { it.isLetter() } == 0) return s
    if (c.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
    c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
        "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$s%"), null)?.use {
        if (it.moveToFirst()) return it.getString(0)
    }
    return null
}

private fun acc() = JarvisAccessibilityService.instance
private val NO_ACC = ToolResult(false, "Enable the Jarvis Accessibility Service first")

fun buildRegistry(c: Context): ToolRegistry {
    val r = ToolRegistry()
    val audio = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val mem = c.getSharedPreferences("mem", Context.MODE_PRIVATE)

    // ---- Apps & settings ----
    r.add(FnTool("open_app", "Open an installed app by name", "name") { a ->
        val q = a.optString("name").lowercase(); val pm = c.packageManager
        val hit = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
        val li = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        if (li == null) ToolResult(false, "App not found: $q") else go(c, li)
    })
    r.add(FnTool("open_settings", "Open a settings page: wifi,bluetooth,display,sound,battery,notifications,apps,accessibility,location,storage,date,language,privacy,security,developer,default_apps,main", "page") { a ->
        val act = when (a.optString("page")) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS; "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY; "notifications" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS; "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS; "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "date" -> Settings.ACTION_DATE_SETTINGS; "language" -> Settings.ACTION_LOCALE_SETTINGS
            "privacy" -> Settings.ACTION_PRIVACY_SETTINGS; "security" -> Settings.ACTION_SECURITY_SETTINGS
            "developer" -> Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
            "default_apps" -> Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        val i = Intent(act); if (act == Settings.ACTION_APP_NOTIFICATION_SETTINGS) i.putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName)
        go(c, i)
    })

    // ---- Communication (always opens the composer / dialer; you press send/call) ----
    r.add(FnTool("find_contact", "Look up a contact's number", "name") { a ->
        resolveNumber(c, a.optString("name"))?.let { ToolResult(true, it) } ?: ToolResult(false, "Contact not found / no permission")
    })
    r.add(FnTool("dial", "Open dialer with a number or contact name", "to") { a ->
        val n = resolveNumber(c, a.optString("to")) ?: return@FnTool ToolResult(false, "Number not found")
        go(c, Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n")))
    })
    r.add(FnTool("draft_sms", "Open SMS composer with text prefilled", "to,text") { a ->
        val n = resolveNumber(c, a.optString("to")) ?: return@FnTool ToolResult(false, "Number not found")
        go(c, Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$n")).putExtra("sms_body", a.optString("text")))
    })
    r.add(FnTool("draft_whatsapp", "Open WhatsApp chat with text prefilled", "to,text") { a ->
        val n = resolveNumber(c, a.optString("to"))?.filter { it.isDigit() } ?: return@FnTool ToolResult(false, "Number not found")
        go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$n?text=" + URLEncoder.encode(a.optString("text"), "UTF-8"))))
    })
    r.add(FnTool("share_text", "Share text via Android share sheet", "text") { a ->
        go(c, Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, a.optString("text")), "Share"))
    })

    // ---- Web / maps / camera ----
    r.add(FnTool("web_search", "Google search in browser", "query") { a ->
        go(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + URLEncoder.encode(a.optString("query"), "UTF-8"))))
    })
    r.add(FnTool("open_url", "Open a website", "url") { a -> go(c, Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url")))) })
    r.add(FnTool("navigate", "Open Maps directions/search for a place", "place") { a ->
        go(c, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.optString("place")))))
    })
    r.add(FnTool("open_camera", "Open the camera", "") { go(c, Intent(MediaStore.ACTION_IMAGE_CAPTURE)) })
    r.add(FnTool("youtube_search", "Search YouTube", "query") { a ->
        go(c, Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra(SearchManager.QUERY, a.optString("query")))
    })

    // ---- Time ----
    r.add(FnTool("set_alarm", "Set alarm (24h)", "hour,minute,label") { a ->
        go(c, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour")).putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
            .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    })
    r.add(FnTool("set_timer", "Start a timer", "seconds") { a ->
        go(c, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds")).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    })
    r.add(FnTool("add_event", "Create calendar event (opens editor)", "title,minutes_from_now,duration_min") { a ->
        val start = System.currentTimeMillis() + a.optLong("minutes_from_now") * 60000
        go(c, Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI).putExtra(CalendarContract.Events.TITLE, a.optString("title"))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, start + a.optLong("duration_min", 30) * 60000))
    })

    // ---- Device ----
    r.add(FnTool("device_status", "Battery, storage, network, bluetooth status", "") {
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val pct = b?.let { it.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) * 100 / it.getIntExtra(BatteryManager.EXTRA_SCALE, 100) } ?: -1
        val chg = (b?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        val st = StatFs(Environment.getDataDirectory().path)
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        val net = when { caps == null -> "offline"; caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"; caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"; else -> "other" }
        val bt = try { if (BluetoothAdapter.getDefaultAdapter()?.isEnabled == true) "on" else "off" } catch (e: Exception) { "unknown" }
        ToolResult(true, "battery $pct%${if (chg) " (charging)" else ""}, free storage ${st.availableBytes / 1_000_000_000} GB, network $net, bluetooth $bt")
    })
    r.add(FnTool("flashlight", "Turn torch on/off", "on:boolean") { a ->
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            ?: return@FnTool ToolResult(false, "No flash")
        cm.setTorchMode(id, a.optBoolean("on", true)); ToolResult(true, "torch")
    })
    r.add(FnTool("volume", "Set media volume 0-100, or direction up/down", "level|direction") { a ->
        if (a.has("level")) audio.setStreamVolume(AudioManager.STREAM_MUSIC, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC) * a.optInt("level") / 100, AudioManager.FLAG_SHOW_UI)
        else audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (a.optString("direction") == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        ToolResult(true, "volume")
    })
    r.add(FnTool("media", "Media key: play_pause,next,previous", "action") { a ->
        val k = when (a.optString("action")) { "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS; else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE }
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, k)); audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, k)); ToolResult(true, "media")
    })

    // ---- Memory ----
    r.add(FnTool("remember", "Save a fact/preference", "key,value") { a -> mem.edit().putString(a.optString("key"), a.optString("value")).apply(); ToolResult(true, "saved") })
    r.add(FnTool("forget", "Delete a saved fact", "key") { a -> mem.edit().remove(a.optString("key")).apply(); ToolResult(true, "deleted") })
    r.add(FnTool("wait", "Pause between steps (ms, max 5000)", "ms") { a -> delay(a.optLong("ms", 1000).coerceIn(0, 5000)); ToolResult(true, "waited") })

    // ---- Screen control via Accessibility ----
    r.add(FnTool("ui_global", "System action: back,home,recents,notifications,quick_settings,lock,screenshot", "action") { a ->
        val s = acc() ?: return@FnTool NO_ACC; ToolResult(s.global(a.optString("action")), a.optString("action"))
    })
    r.add(FnTool("ui_read", "Read text currently on screen", "") { ToolResult(acc() != null, acc()?.readScreen()?.take(500) ?: "Accessibility off") })
    r.add(FnTool("ui_click", "Tap a button/text visible on screen", "text", risky = true) { a ->
        val s = acc() ?: return@FnTool NO_ACC; ToolResult(s.clickText(a.optString("text")), "click ${a.optString("text")}")
    })
    r.add(FnTool("ui_type", "Type text into the focused field", "text", risky = true) { a ->
        val s = acc() ?: return@FnTool NO_ACC; ToolResult(s.typeText(a.optString("text")), "typed")
    })
    r.add(FnTool("ui_scroll", "Scroll the screen: direction down/up", "direction") { a ->
        val s = acc() ?: return@FnTool NO_ACC; ToolResult(s.scroll(a.optString("direction") != "up"), "scroll")
    })
    return r
}
