package com.jarvis.agent.agent

import android.content.Context
import com.jarvis.agent.service.JarvisAccessibilityService
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date

class AgentEngine(private val ctx: Context, private val registry: ToolRegistry, private val planner: Planner) {
    private val history = mutableListOf<String>()
    @Volatile var stopped = false

    suspend fun handle(text: String, say: (String) -> Unit, confirm: suspend (String) -> Boolean) {
        stopped = false
        val mem = ctx.getSharedPreferences("mem", Context.MODE_PRIVATE).all.entries.joinToString("; ") { "${it.key}=${it.value}" }
        val screen = JarvisAccessibilityService.instance?.readScreen()?.take(2000) ?: "(accessibility off)"
        val now = SimpleDateFormat("EEE yyyy-MM-dd HH:mm").format(Date())
        val plan = try { planner.plan(text, history.takeLast(10), registry.catalog(), "NOW: $now\nMEMORY: $mem\nSCREEN:\n$screen") }
        catch (e: Exception) { say("Planner error: ${e.message}"); return }

        val reply = plan.optString("reply")
        if (reply.isNotBlank()) say(reply)
        val steps = plan.optJSONArray("steps")
        if (steps != null) for (i in 0 until steps.length()) {
            if (stopped) { say("Stopped."); break }
            val s = steps.getJSONObject(i)
            val name = s.optString("tool")
            val args = s.optJSONObject("args") ?: JSONObject()
            val tool = registry.get(name)
            if (tool == null) { say("✗ Unknown tool: $name"); break }
            if (tool.risky && !confirm("$name $args")) { say("Skipped $name"); continue }
            val r = try { tool.run(args) } catch (e: Exception) { ToolResult(false, e.message ?: "error") }
            say((if (r.ok) "✓ " else "✗ ") + name + ": " + r.message)
            if (!r.ok) break
        }
        history.add("U: $text"); history.add("A: $reply")
    }
}
