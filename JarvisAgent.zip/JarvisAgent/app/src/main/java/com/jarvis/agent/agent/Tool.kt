package com.jarvis.agent.agent

import org.json.JSONObject

data class ToolResult(val ok: Boolean, val message: String)

interface Tool {
    val name: String
    val description: String
    val args: String
    val risky: Boolean get() = false
    suspend fun run(a: JSONObject): ToolResult
}

class FnTool(
    override val name: String, override val description: String, override val args: String,
    override val risky: Boolean = false, private val fn: suspend (JSONObject) -> ToolResult
) : Tool { override suspend fun run(a: JSONObject) = fn(a) }

class ToolRegistry {
    private val m = linkedMapOf<String, Tool>()
    fun add(t: Tool) { m[t.name] = t }
    fun get(n: String) = m[n]
    fun catalog() = m.values.joinToString("\n") { "- ${it.name}(${it.args}): ${it.description}" }
}
